#!/usr/bin/env python
#-*- coding: UTF-8 -*-
import sys
from conf.ParserConf import parser_conf
from mapred.MapTask import MapTask
from common.Log import Log

if __name__ == '__main__':
    logger = Log()
    if len(sys.argv) < 2:
        logger.fatal('usage: ./Extractor.py log_type')
        sys.exit(-1)
    
    log_type = sys.argv[1]
    log_type = log_type.strip()

    if log_type in parser_conf:
        conf_dict = parser_conf[log_type]
        if 'schema' in conf_dict:
            schema = conf_dict['schema']
            ret = schema.parse()
            if not ret:
                logger.fatal('schema parse failed.')
                sys.exit(-1)

        if 'parser' in conf_dict:
            parser = conf_dict['parser']
            map_task = MapTask(parser)
            
            map_task.run()
        else:
            logger.fatal('parser obj is not configured.')

    else:
        logger.fatal('type [%s] is not configured.' %(log_type))
