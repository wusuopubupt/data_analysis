#!/bin/env python

import re
import sys
sys.path.append("..")
from common.Schema import SchemaParser
from regex.Baiduplayer import regex_str


if __name__ == '__main__':
    table_schema = SchemaParser('../HQL/baiduplayer/BaiduplayerTable.hql')
    table_schema.parse()
    parser = Parser(regex_str, table_schema)
    for line in sys.stdin:
        output = parser.parse(line)
        print output
