#!/usr/bin/evn python
#-*- coding: UTF-8 -*-

import sys
from common.Parser import Parser
from common.Schema import SchemaParser
from udf.DeepParser import DeepParser

import regex.BaiduplayerRegex

#��ȡExtractor�ű�·��
path = sys.path[0]
hql_dir = path + '/HQL/'

# parser conf
parser_conf = {}

# Ϊÿ�ֲ�ͬ����־ʵ�ֶ�Ӧ������

# 1. Baiduplayer
baiduplayer_regex_str = regex.BaiduplayerRegex.regex_str
baiduplayer_schema = SchemaParser(hql_dir + 'baiduplayer/BaiduplayerTable.hql')
baiduplayer_parser = Parser(baiduplayer_regex_str, baiduplayer_schema)
baiduplayer_conf = {'type' : 'baiduplayer', 'parser' : baiduplayer_parser, 'schema' : baiduplayer_schema}
parser_conf['baiduplayer'] = baiduplayer_conf
