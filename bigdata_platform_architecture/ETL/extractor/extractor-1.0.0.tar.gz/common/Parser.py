#!/bin/env python
#-*- coding: UTF-8 -*-
import re
import sys
from Log import Log
from datetime import datetime
from urlparse import urlparse
from urlparse import parse_qs


class Parser:
    '''
    basic log parser class
    '''

    def __init__(self, regex_str, schema_parser):
        self.__regex_str = regex_str;
        self.__pattern = re.compile(regex_str)
        self.schema_parser = schema_parser
        self.logger = Log()

    def get_value(self, query_dict, k):
        if k in query_dict:
            return query_dict[k]
        return 'dummy'
        

    def parse(self, line):
        fields_list = line.strip().split('\001')

        """ 
['172.22.75.52', '18/Dec/2015:18:02:01', 'GET', '499', 'HTTP/1.1', '/yingyin/sportindex?a=bx', '-', '__bdvnidxset=0,0,0,0,1; BAIDUID=BF1F8CD3BA73501BBBF38F457B3FCC20:FG=1; BIDUPSID=BF1F8CD3BA73501BBBF38F457B3FCC20; PSTM=1446314273; __bdvnindex=1; H_PS_PSSID=17519_1447_18280_18156_17946_10212_18500_17000_17072_15567_11974_10632; BDV_TRACE=1450427579490:; bdv_right_ad_poster=1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/47.0.2526.106 Safari/537.36\n172.22.75.52', '18/Dec/2015:18:02:01', 'GET', '499', 'HTTP/1.1', '/yingyin/sportindex?a=bx', '-', '__bdvnidxset=0,0,0,0,1; BAIDUID=BF1F8CD3BA73501BBBF38F457B3FCC20:FG=1; BIDUPSID=BF1F8CD3BA73501BBBF38F457B3FCC20; PSTM=1446314273; __bdvnindex=1; H_PS_PSSID=17519_1447_18280_18156_17946_10212_18500_17000_17072_15567_11974_10632; BDV_TRACE=1450427579490:; bdv_right_ad_poster=1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/47.0.2526.106 Safari/537.36']
        """

        ip = fields_list[0]
        date_time = datetime.strptime(fields_list[1], '%d/%b/%Y:%H:%M:%S').strftime('%Y%m%d %H:%M:%S')
        date_time_dict = date_time.split(' ') 
        event_date = date_time_dict[0]
        event_time = date_time_dict[1]
        url = fields_list[5]
        # parse url
        parse_res_dict = urlparse(url)
        path = parse_res_dict.path
        query = parse_res_dict.query
        # parse query string
        qs = dict((k, v if len(v) > 1 else v[0]) for k, v in parse_qs(query).iteritems())

        kv_dict = []
        for k, v in qs.iteritems():
            kv_dict.append(k+","+v)
        url_fields = '\002'.join(kv_dict)

        module = self.get_value(qs, 'module')
        pid = self.get_value(qs, 'pid')
        app = self.get_value(qs, 'app')
        pccode = self.get_value(qs, 'pccode')
        version = self.get_value(qs, 'version')
        channel = self.get_value(qs, 'channel')

        #line = 'event_date=20150312 event_time=12:03:55 module=bdyy pid=312 app=baiduplayer5 pccode=abcedefghijklmn version=4.1.2 channel=135 ip=123.11.14.32'
        line = 'event_date=%s event_time=%s module=%s pid=%s app=%s pccode=%s version=%s channel=%s ip=%s url_fields=%s' % \
               (event_date, event_time, module, pid, app, pccode, version, channel, ip, url_fields)
        result = self.__pattern.search(line)

        if result:
            ret = self.do_parse(result)
            if not ret:
                self.logger.fatal('parse line [%s] failed.' %(line))
            return ret
        else:
            return None

    def do_parse(self, regex_search_result):
        regex_dict = regex_search_result.groupdict();
        schema = self.schema_parser.schema()
        columns = []
        for column in schema:
            try:
                key = column['name']
                # source_host �Ǵ�mapred�л�ȡ�ģ�������������־
                if key == 'source_host':
                    continue

                if key in regex_dict:
                    column_value = regex_dict[key]
                    columns.append(column_value)
                # ֻҪHIVE���и�һ���ֶ�û����־��Ͷ���
                else:
                    self.logger.fatal('regex_dict has no key[%s]' %(key))
                    return None
            except KeyError,e:
                self.logger.fatal('Exception in log parser:%s' %(e))
                return None
        
        output_str = '\001'.join(columns)
        return output_str
