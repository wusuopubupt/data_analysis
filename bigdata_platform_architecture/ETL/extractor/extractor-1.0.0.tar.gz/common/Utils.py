#!/usr/bin/env python
#-*- coding: UTF-8 -*-
import re
from Log import Log


class Utils:
    '''
    utils class
    '''

    def __init__(self, regex_str, schema_parser):
        self.__regex_str = regex_str;
        self.__pattern = re.compile(regex_str)
        self.schema_parser = schema_parser
        self.logger = Log()

    def parse(self, line):
        result = self.__pattern.search(line)
        if result:
            ret = self.do_parse(result)
            if not ret:
                self.logger.fatal('parse line [%s] failed.' %(line))
            return ret
        else:
            return None

    def do_parse(self, regex_search_result):
        regex_dict = regex_search_result.groupdict();
        schema = self.schema_parser.schema()
        columns = []
        for column in schema:
            try:
                key = column['name']
                # source_host �Ǵ�mapred�л�ȡ�ģ�������������־
                if key == 'source_host':
                    continue

                if key in regex_dict:
                    column_value = regex_dict[key]
                    columns.append(column_value)
                else:
                    self.logger.fatal('regex_dict has no key[%s]' %(key))
                    return None
            except KeyError,e:
                self.logger.fatal('Exception in log parser:%s' %(e))
                return None
        
        output_str = '\001'.join(columns)
        return output_str
