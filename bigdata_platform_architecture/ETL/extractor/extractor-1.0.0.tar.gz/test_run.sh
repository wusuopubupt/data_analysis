#!/bin/bash
cat data/baiduplayer.log | python Extractor.py baiduplayer
