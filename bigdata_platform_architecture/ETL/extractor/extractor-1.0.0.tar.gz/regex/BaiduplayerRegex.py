#!/bin/env python
#-*- coding: UTF-8 -*- 
import re

regex_str = 'event_date=(?P<event_date>\w+) event_time=(?P<event_time>\d{2}:\d{2}:\d{2}) module=(?P<module>\w+) pid=(?P<pid>\w+) app=(?P<app>\w+) pccode=(?P<pccode>[\w\-]+) version=(?P<version>[\w\.]+) channel=(?P<channel>\w+) ip=(?P<ip>[\d\.]+) url_fields=(?P<url_fields>.*)'


if __name__ == '__main__':

    log_str = '''event_date=20150312 event_time=12:03:55 module=bdyy pid=312 app=baiduplayer5 pccode=abcedefghijklmn version=4.1.2 channel=135 ip=123.11.14.32'''

    log_str = log_str.strip()

    print log_str
    print regex_str

    pattern = re.compile(regex_str)
    result = pattern.search(log_str)
    if result:
        print "Bingo!"
        print result.groupdict()
    else:
        print "None."

