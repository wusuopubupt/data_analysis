#!/usr/bin/env python
#-*- coding: UTF-8 -*-
import sys
import os
import subprocess

class MapTask:
    '''
       Map task for log parser
    '''
    def __init__(self, parser):
        self.parser = parser

    def run(self):
        source_host = self.get_src_hostname()

        for line in sys.stdin:
            line = line.strip()
            if len(line) == 0:
                continue

            # nginx日志解析
            cmd = "echo '%s' | sh extractor/common/nginx_log_parser.sh" % line.replace("'", "&#39;")
            #cmd = "echo '%s' | sh common/nginx_log_parser.sh" % line.replace("'", "&#39;")
            newline = subprocess.check_output(cmd, shell=True)
            result = self.parser.parse(newline)

            if result:
                # hive表以001作为分隔符
                print '%s\001%s\001' %(source_host, result)

    def get_src_hostname(self):
        env = os.environ
        hostname=''

        if 'map_input_file' in env:
            # 从环境变量中获取MR任务的输入文件名, 区分各个不同源
            map_file_path = env['map_input_file']
            return map_file_path
            filename = map_file_path.split('/')[-1]
            hostname = filename.split('_')[1]

        return hostname

