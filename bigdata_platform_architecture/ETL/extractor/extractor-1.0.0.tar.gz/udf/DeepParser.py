#!/bin/env python
#-*- coding: UTF-8 -*-

import socket
from common.Parser import Parser


class DeepParser(Parser):
    '''
    parser for timeout log between moudles
    there must ip in the log
    '''

    def do_parse(self, regex_search_result):
        regex_dict = regex_search_result.groupdict();
        tmp_dict = {}
        for key in regex_dict:
            tmp_dict[key] = regex_dict[key]
        
        self.deep_parser(regex_dict['ip'], tmp_dict)

        schema = self.schema_parser.schema()
        columns = []
        for column in schema:
            column_name = column['name']
            if column_name == 'source_host':
                continue

            if key in tmp_dict:
                column_value = tmp_dict[column['name']]
                columns.append(column_value)
            else:
                self.logger.fatal('regex_dict has no key[%s]' %(key))
                return None

        output_str = '\001'.join(columns)
        return output_str

    def deep_parser(self, ip, parsed_dict):
        ip_b = self.get_ip_b_addr(ip)
        parsed_dict['ip_b'] = ip_b
        ip_c = self.get_ip_c_addr(ip)
        parsed_dict['ip_c'] = ip_c
        host_name = self.get_host_name(ip)
        parsed_dict['hostname'] = host_name
        cluster = self.get_cluster_name(host_name)
        parsed_dict['data_center'] = cluster

    def get_ip_b_addr(self, ip):
        ip_nums = ip.split('.')
        ip_nums[3] = '*'
        ip_b = '.'.join(ip_nums)
        return ip_b;

    def get_ip_c_addr(self, ip):
        ip_nums = ip.split('.')
        ip_nums[2] = '*'
        ip_nums[3] = '*'
        ip_c = '.'.join(ip_nums)
        return ip_c;

    def get_host_name(self, ip):
        host_name = socket.getfqdn(ip)
        return host_name

    def get_cluster_name(self, host_name):
        cluster = host_name.split('-')[0]
        return cluster



